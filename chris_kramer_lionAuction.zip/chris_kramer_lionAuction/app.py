import csv
import hashlib
from flask import Flask, render_template, request

app = Flask(__name__)


# securely hash the password
def hash_password(password):
    return hashlib.sha256(password.encode('utf-8')).hexdigest()


# loop through the file to see if they are a real user and can log in
def authenticate(username, password):
    with open('users.csv', 'r') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            if row[0] == username and row[1] == hash_password(password):
                return True
    return False


# connect html file to our flask shit
@app.route('/')
def index():
    return render_template('loginpage.html')


# gathers the user's login information, runs the authenticate method, and either logs them in or nah
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    if authenticate(username, password):
        return 'Login successful'
    else:
        return 'Login failed'


if __name__ == '__main__':
    app.run(debug=True)
