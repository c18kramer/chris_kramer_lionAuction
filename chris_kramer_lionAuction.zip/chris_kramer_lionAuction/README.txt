User login screen for LionAuctin.

User can log in with username and password.

Do not enter a fake username and password.